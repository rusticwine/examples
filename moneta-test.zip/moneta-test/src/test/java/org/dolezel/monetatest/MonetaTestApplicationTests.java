package org.dolezel.monetatest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonetaTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
